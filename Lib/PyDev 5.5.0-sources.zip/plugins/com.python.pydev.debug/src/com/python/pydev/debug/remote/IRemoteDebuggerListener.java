package com.python.pydev.debug.remote;

public interface IRemoteDebuggerListener {

    void stopped(RemoteDebuggerServer remoteDebuggerServer);

}
