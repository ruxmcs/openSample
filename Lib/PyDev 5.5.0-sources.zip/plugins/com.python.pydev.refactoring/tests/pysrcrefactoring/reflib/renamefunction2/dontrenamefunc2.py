class RenameFunc2:
    
    def Bar(self): #rename this method
        pass
        
RenameFunc2.Bar