from reflib.renamefunction2.renamefunc2 import RenameFunc2

class RenameFunc3(RenameFunc2):
    
    def RenameFunc2(self): #rename this method
        self.bar.RenameFunc2
        
RenameFunc2.RenameFunc2 #and only the 2nd part of the access