def m1():
    class LocalFoo:
        pass
    print LocalFoo
    
class LocalFoo:
    pass
print LocalFoo
    
