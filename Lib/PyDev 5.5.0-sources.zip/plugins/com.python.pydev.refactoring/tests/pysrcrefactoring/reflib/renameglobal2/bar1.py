from cPickle import BadPickleGet




Bar1 = BadPickleGet