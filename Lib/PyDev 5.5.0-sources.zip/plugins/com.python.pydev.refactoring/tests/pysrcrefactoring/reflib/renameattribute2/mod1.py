class MyClass:

    def method(self, param):
        if param.attribute_to_be_found:
            pass
