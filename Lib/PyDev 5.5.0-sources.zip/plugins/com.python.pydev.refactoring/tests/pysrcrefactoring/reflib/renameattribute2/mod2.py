class Container:

    def method(self):
        self.attribute_to_be_found = True
