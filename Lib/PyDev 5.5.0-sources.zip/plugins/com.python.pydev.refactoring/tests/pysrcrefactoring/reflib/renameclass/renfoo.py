class RenFoo(object):
    pass

print RenFoo

#comment: RenFoo must be renamed
'string: RenFoo must be renamed'