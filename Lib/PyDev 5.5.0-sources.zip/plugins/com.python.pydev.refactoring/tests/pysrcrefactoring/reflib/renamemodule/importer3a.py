from reflib.renamemodule import importer2

my = importer2.submod1  #must be renamed because it'll be renamed on importer2
