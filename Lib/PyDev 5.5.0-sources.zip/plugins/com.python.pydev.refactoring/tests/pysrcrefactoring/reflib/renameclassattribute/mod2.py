class ClassWithAttr:

    class_attribute_to_be_found = True
    
    def method(self):
        ClassWithAttr.class_attribute_to_be_found = True
