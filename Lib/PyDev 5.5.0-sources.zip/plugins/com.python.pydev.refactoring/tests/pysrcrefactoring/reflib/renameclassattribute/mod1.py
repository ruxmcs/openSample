class MyClass:

    def method(self, param):
        if param.class_attribute_to_be_found:
            pass
