global bar
bar = 10
print bar