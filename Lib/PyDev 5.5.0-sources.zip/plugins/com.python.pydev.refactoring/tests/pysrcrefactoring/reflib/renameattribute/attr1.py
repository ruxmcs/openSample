class Attr1(object):
    def __init__(self):
        self.attrInstance = 1