class Mod1:
    pass