package com.python.pydev.analysis.search_index;

import org.python.pydev.shared_ui.search.AbstractSearchIndexQuery;
import org.python.pydev.shared_ui.search.SearchIndexResult;

public class PySearchResult extends SearchIndexResult {

    public PySearchResult(AbstractSearchIndexQuery searchIndexQuery) {
        super(searchIndexQuery);
    }

}
