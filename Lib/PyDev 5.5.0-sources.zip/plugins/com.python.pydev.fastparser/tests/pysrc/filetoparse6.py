class Class1  (  object  , RuntimeError  )  :  pass
class Class2  :  pass