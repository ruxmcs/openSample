def GlobalMethod  (  param1  ,  param2  )  :   #comment
    '''GlobalMethod docs'''