class Class1(object):
    'Class1 docs'
    
    def meth1(self):
        '''Will not be gotten by fast parse
        '''
        
        pass