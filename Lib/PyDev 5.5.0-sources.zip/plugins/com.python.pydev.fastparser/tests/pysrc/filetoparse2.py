class Class1(object):
    'Class1 docs'
        
def GlobalMethod(param1):
    '''GlobalMethod docs'''
    
def OtherGlobalMethod(param1, param2):    
    '''OtherGlobalMethod 
    multiline docs
    '''