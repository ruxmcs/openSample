Licensed under the terms of the Eclipse Public License (EPL).

Please see the license.txt included with this distribution for details.

PyDev is a Python plugin for Eclipse. See http://pydev.org for more details.

To get started in PyDev, read: http://pydev.org/manual_101_root.html

For developing PyDev, read: http://pydev.org/developers.html