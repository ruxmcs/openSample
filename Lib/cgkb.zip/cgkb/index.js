const _ = require('lodash')
const path = require('path')
const cgkb = require(path.join(__dirname, 'src', 'cgkb'))

module.exports = cgkb
